create definer = root@`%` trigger address_format_trigger
    before insert
    on user
    for each row
BEGIN
    IF NEW.Address NOT REGEXP '^.*省.*市.*县.*$' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid address format';
    END IF;
END;

